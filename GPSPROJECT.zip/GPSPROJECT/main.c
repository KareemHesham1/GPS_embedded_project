#include "tm4c123gh6pm.h"
#include <string.h>
#include <stdint.h>
#include <math.h>
#define CR 0x0D
#include <stdio.h>
#include <stdlib.h>
#define MAX_ROWS 15
#define MAX_COLS 15

char command[100]={0};
char result[15][15]={0};
int row_count=0;
float distance=0;
float current_long=0;
float next_long=0;
float current_lat=0;
float next_lat=0;

void splitString(char *inputString, char delimiter, char result[MAX_ROWS][MAX_COLS], int *rowCount) {
    int i;
    int row = 0, col = 0;

    for (i = 0; inputString[i] != '\0'; i++) {
        if (inputString[i] != delimiter) {
            result[row][col++] = inputString[i];
        } else {
            result[row][col] = '\0'; // Null-terminate the string
            row++;
            col = 0;
        }
    }
    result[row][col] = '\0'; // Null-terminate the last string
    *rowCount = row + 1; // Update the number of rows
}
 
void init_rgb(void)
{
	SYSCTL_RCGCGPIO_R |=0x20;
	while((SYSCTL_RCGCGPIO_R & 0x20) == 0);
	GPIO_PORTF_LOCK_R =0x4C4F434B;
	GPIO_PORTF_CR_R|=0x0E;
	GPIO_PORTF_AMSEL_R&=~0x0E;
	GPIO_PORTF_PCTL_R&=~0x0000FFF0;
	GPIO_PORTF_AFSEL_R&=~0x0E;
	GPIO_PORTF_DIR_R|=0x0E;
	GPIO_PORTF_DEN_R|=0x0E;
	GPIO_PORTF_DATA_R&=~0x0E;
}


void init_sw1(void)
{
	SYSCTL_RCGCGPIO_R |=0x20;
	while((SYSCTL_RCGCGPIO_R & 0x20) == 0);
	GPIO_PORTF_LOCK_R =0x4C4F434B;
	GPIO_PORTF_CR_R|=0x10;
	GPIO_PORTF_AMSEL_R&=~0x10;
	GPIO_PORTF_PCTL_R&=~0x000F0000;
	GPIO_PORTF_AFSEL_R&=~0x10;
	GPIO_PORTF_DIR_R &=~ 0x10;
	GPIO_PORTF_PUR_R|=0x10;
	GPIO_PORTF_DEN_R|=0x10;
}

unsigned char sw1_input(void)
{
	return GPIO_PORTF_DATA_R&0x10;
}

void rgp_output(unsigned char data)
{
	GPIO_PORTF_DATA_R&=~0x0E;
	GPIO_PORTF_DATA_R|=data;
}

void uart_init(void)
{
	SYSCTL_RCGCUART_R|=0x0001;
	SYSCTL_RCGCGPIO_R|=0x0001;
	UART0_CTL_R&=~0x0001;
	UART0_IBRD_R=104;
  UART0_FBRD_R=11;
	UART0_LCRH_R=0x0070;
	UART0_CTL_R=0x0301;
	GPIO_PORTA_AFSEL_R|=0x03;
	GPIO_PORTA_PCTL_R=(GPIO_PORTA_PCTL_R&0xFFFFFF00)+0x00000011;
	GPIO_PORTA_DEN_R|=0x03;
	GPIO_PORTA_AMSEL_R&=~0x03;
}


char read_byte(void)
{
	while((UART0_FR_R&0x010)!=0);
	return (char)(UART0_DR_R&0xFF);
	
}



void transmit_byte(char data)
{
	while((UART0_FR_R&0x020)!=0);
	UART0_DR_R=data;
	
}


void recive_command(char *command,int len)
{
	char character;
	int i;
	for(i=0;i<len;i++)
	{
		
		
		character=read_byte();
		if(character!=CR)
		{
			command[i]=character;
			transmit_byte(command[i]);
		}
		else if (character==CR || i==len) break;
		
	}		
}


void output_command (char * pt)
{
	while(*pt)
	{
		transmit_byte(*pt);
		pt++;
		
	}
}


void delay(unsigned long delay)
{
	NVIC_ST_CTRL_R=0x00;
	NVIC_ST_RELOAD_R=delay-1;
	NVIC_ST_CURRENT_R=0;
	NVIC_ST_CTRL_R=0x05;
	while((NVIC_ST_CTRL_R&0x00010000)==0){}
}


float todeg (float angle)
{
	float degree=(float)angle/100;
	float minutes =angle-(float)degree*100;
	return(degree+(minutes/60));
}

float torad (float angle)
{
	return ((angle*3.14159265359)/180);
}

float get_distance(float current_long,float current_lat,float next_long,float next_lat)
{
	float current_long_rad=torad(todeg(current_long));
	float current_lat_rad=torad(todeg(current_lat));
	float next_long_rad=torad(todeg(next_long));
	float next_lat_rad=torad(todeg(next_lat));
	float longdiff=next_long_rad-current_long_rad;
	float latdiff=next_lat_rad-current_lat_rad;
	float  a=pow(sin(latdiff/2),2)+cos(current_lat_rad)*cos(next_lat_rad)*pow(sin(longdiff/2),2);
  float  c=2*atan2(sqrt(a),sqrt(1-a));
	return 6371000*c;
}

float d (void){
	float dd=0;
	recive_command(command,100);
	output_command("\n");
	splitString(command, ',', result, & row_count);
	
	while((strcmp(result[0],"$GPRMC")&&strcmp(result[2],"A"))!=0)
		{
			recive_command(command,100);
			output_command("\n");
		  memset(result,0,sizeof(result));
	    splitString(command, ',', result, & row_count);
		}
	
		if(strcmp(result[4],"N")==0)
		{
			 current_lat=0;
			 current_lat=atof(result[3]);
		}
		else
		{
			 current_lat=0;
			 current_lat=-1*(atof(result[3]));
		}
	 if(strcmp(result[6],"W")==0)
		{
			current_long=0;
			current_long=-1*(atof(result[5]));
		}
		else
		{
			 current_long=0;
			 current_long=(atof(result[5]));
		}
		distance=distance+get_distance(current_long,current_lat,next_long,next_lat);
	  memset(result,0,sizeof(result));
		memset(command,0,sizeof(command));		
		recive_command(command,100);
	  output_command("\n");
	  splitString(command, ',', result, & row_count);
	
	while(strcmp(result[0],"$GPRMC")!=0)
		{
			recive_command(command,100);
			output_command("\n");
		  memset(result,0,sizeof(result));
	    splitString(command, ',', result, & row_count);
		}
	while(strcmp(result[2],"A")!=0)
		{
			recive_command(command,100);
			output_command("\n");
		  memset(result,0,sizeof(result));
		  splitString(command, ',', result, & row_count);
	}
	
		if(strcmp(result[4],"N")==0)
		{
			 next_lat=0;
			 next_lat=atof(result[3]);
		}
		else
		{
			 next_lat=0;
			 next_lat=-1*(atof(result[3]));
		}
	 if(strcmp(result[6],"E")==0)
		{
			next_long=0;
			next_long=atof(result[5]);
		}
		else
		{
			next_long=0;
			next_long=-atof(result[5]);
		}
		dd=dd+get_distance(current_long,current_lat,next_long,next_lat);
	  memset(result,0,sizeof(result));
		memset(command,0,sizeof(command));
		
		return dd ;
}

char D[30]={0};

int main()
{
 
	init_sw1();
	init_rgb();
	uart_init();
	float distance = 0;

	while(1)
	{
		char input_swtch= sw1_input();
		distance= distance + d();
		sprintf(D,"%f",distance);
		output_command(D);
		output_command("\n");
		if( input_swtch == 0 || distance > 100){
		rgp_output(0x08);
			break;
		}
	}
}
