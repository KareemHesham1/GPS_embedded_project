#include "tm4c123gh6pm.h"
#include<string.h>
#include<stdint.h>
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>


char test2[15]={0};
 char test[100]="";
    char splited[15][15]={0};
        float current_lat =0;
        float current_long=0;
        float next_lat=0;
        float next_long=0;

float distance =0;





void delay(long d)
{
   while(d--);
}

void Printdata(uint8_t data)
{
    // data = 8 bit hexadecimal data
  if ((data&0x01) ==0x01)
    GPIO_PORTA_DATA_R |= 0x80;
  else
    GPIO_PORTA_DATA_R &= ~0x80;

  if ((data &0x02) ==0x02)
    GPIO_PORTA_DATA_R |= 0x40;
  else
    GPIO_PORTA_DATA_R &= ~0x40;

  if ((data &0x04)==0x04)
    GPIO_PORTA_DATA_R |= 0x20;
  else
    GPIO_PORTA_DATA_R &= ~0x20;

  if ((data &0x08) ==0x08)
    GPIO_PORTB_DATA_R |= 0x10;
  else
    GPIO_PORTB_DATA_R &= ~0x10;

  if ((data &0x10) ==0x10)
    GPIO_PORTE_DATA_R |= 0x20;
  else
    GPIO_PORTE_DATA_R &= ~0x20;

  if ((data &0x20) ==0x20)
    GPIO_PORTE_DATA_R |= 0x10;
  else
    GPIO_PORTE_DATA_R &= ~0x10;

  if ((data &0x40) ==0x40)
    GPIO_PORTB_DATA_R |= 0x02;
  else
    GPIO_PORTB_DATA_R &= ~0x02;

  if ((data &0x80) ==0x80)
    GPIO_PORTB_DATA_R |= 0x01;
  else
    GPIO_PORTB_DATA_R &= ~0x01;
}

void LCD_CMD(uint8_t cmd)
{

    Printdata(cmd);                  //pass the 8bit data in the datalines of lcd
    GPIO_PORTD_DATA_R &= ~ 0x02 ;    //turn off the R/W pin for write operation in lcd
    GPIO_PORTD_DATA_R &= ~ 0x01;     //turn off the RS for writing to the instruction register of lcd
    GPIO_PORTD_DATA_R |= 0x04;       //turn on the En of lcd for enabling the clock of lcd
    delay(10000);                    //wait for sometime
    GPIO_PORTD_DATA_R &=~ 0x04;      //Turn off the En of lcd
}

void LCD_Init(void)
{

    SYSCTL_RCGCGPIO_R |= 0x1B;
    while((SYSCTL_PRGPIO_R & 0x0001)==0);

    GPIO_PORTA_DEN_R  |= 0xE0;
    GPIO_PORTB_DEN_R  |= 0x13;
    GPIO_PORTD_DEN_R  |= 0x07;
    GPIO_PORTE_DEN_R  |= 0x30;

    GPIO_PORTA_DIR_R  |= 0xE0;
    GPIO_PORTB_DIR_R  |= 0x13;
    GPIO_PORTD_DIR_R  |= 0x07;
    GPIO_PORTE_DIR_R  |= 0x30;
    LCD_CMD(0x38); //8bit mode utilising 16 columns and 2 rows
    LCD_CMD(0x06); // autoincrementing the cursor when prints the data in current
    LCD_CMD(0x0C); //cursor off and display on
    LCD_CMD(0x01); //clearscreen
}


void LCD_SendChar(uint8_t data)
{
    Printdata(data);                  //pass the data in the datalines of lcd
    GPIO_PORTD_DATA_R &= ~ 0x02 ;    //turn off the R/W pin for write operation in lcd
    GPIO_PORTD_DATA_R |= 0x01;      //turn on the RS for writing to the data register of lcd
    GPIO_PORTD_DATA_R |= 0x04;     //turn on the En of lcd for enabling the clock of lcd
    delay(10000);                            //wait for sometime
    GPIO_PORTD_DATA_R &=~ 0x04;             //Turn off the En of lcd
}

void LCD_SendString(uint8_t *str ,uint8_t len)
{
    uint8_t i;
   for (i=0;i<len;i++){
    LCD_SendChar(str[i]);
     }
}





void portBInit(void)
{

    SYSCTL_RCGCGPIO_R = 0x02;
    while ((SYSCTL_PRGPIO_R & 0x02 ) == 0) {};
      GPIO_PORTB_LOCK_R   = GPIO_LOCK_KEY;
      GPIO_PORTB_CR_R     = 0XFF;
      GPIO_PORTB_AFSEL_R  = 0X00;
      GPIO_PORTB_PCTL_R   = 0X00;
      GPIO_PORTB_AMSEL_R  = 0X00;
      GPIO_PORTB_DIR_R   |= 0XFF;
      GPIO_PORTB_DEN_R   |= 0XFF;
      GPIO_PORTB_DATA_R  &= 0X00;
}



//portf intia

void RGBInit (void){

                SYSCTL_RCGCGPIO_R |= 0X20 ;
                while ((SYSCTL_PRGPIO_R & 0X20) == 0){};
                GPIO_PORTF_LOCK_R = 0x4C4F434B  ;
                GPIO_PORTF_CR_R |=0x0E;
                GPIO_PORTF_AMSEL_R &= ~0x0E;
                GPIO_PORTF_AFSEL_R &= ~0x0E;
                GPIO_PORTF_PCTL_R &= ~0x0000FFF0;
                GPIO_PORTF_DIR_R |=0x0E;
                GPIO_PORTF_DEN_R |=0x0E;
                GPIO_PORTF_DATA_R &= ~0x0E;
        }
// systick timer
void systick_init(void)
{
    NVIC_ST_CTRL_R = 0X00;
    NVIC_ST_RELOAD_R = NVIC_ST_RELOAD_M;

    NVIC_ST_CURRENT_R = 0X00;
    NVIC_ST_CTRL_R = NVIC_ST_CTRL_ENABLE | NVIC_ST_CTRL_CLK_SRC ;
}
void systick_wait_1s(void)
{
    NVIC_ST_RELOAD_R = (16000000) - 1;
    NVIC_ST_CURRENT_R = 0X00;
    while ((NVIC_ST_CTRL_R & NVIC_ST_CTRL_COUNT) == 0x00){}
}
void systick_wait_1ms(void)
{
    NVIC_ST_RELOAD_R = (16000) - 1;
    NVIC_ST_CURRENT_R = 0X00;
    while ((NVIC_ST_CTRL_R & NVIC_ST_CTRL_COUNT) == 0x00) {}
}
void delay_IN_ms(int total)
{
    int i;
    for (i = 0; i < total; i++)
    {
        systick_wait_1ms();
    }
}
//uart0 porta intia
void UART0Init(void){
    SYSCTL_RCGCUART_R |= 0x01;
    SYSCTL_RCGCGPIO_R |= 0x01;

    UART0_CTL_R &= ~0x01; //disable uart
    UART0_IBRD_R = 104 ; //integer baud rate divisor
    UART0_FBRD_R = 11 ; //float baud rate divisor
    UART0_LCRH_R |= 0x70 ; //fifo enable and width  8 bits
    UART0_CTL_R = 0X0301 ; //uart enable , rx enable , tx enable
    GPIO_PORTA_AMSEL_R &= ~0x03; //clear analog mode
    GPIO_PORTA_AFSEL_R |= 0x03; //set alternate function
    GPIO_PORTA_PCTL_R = (GPIO_PORTA_PCTL_R &= ~0xFF) | 0X00000011; //clear PA0 and PA1 then set them as uart
    GPIO_PORTA_DEN_R |= 0X03; //digital enable
}

void UART7Init(void){
    SYSCTL_RCGCUART_R |= SYSCTL_RCGCUART_R7;
    SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R4;

    UART7_CTL_R &= ~0x01; //disable uart
    UART7_IBRD_R = 104 ; //integer baud rate divisor
    UART7_FBRD_R = 11 ; //float baud rate divisor
    UART7_LCRH_R |= 0x70 ; //fifo enable and width  8 bits
    UART7_CTL_R = 0X0301 ; //uart enable , rx enable , tx enable
    GPIO_PORTE_DEN_R |= 0X03; //digital enable
    GPIO_PORTE_AMSEL_R &= ~0x03; //clear analog mode
    GPIO_PORTE_AFSEL_R |= 0x03; //set alternate function
    GPIO_PORTE_PCTL_R = (GPIO_PORTE_PCTL_R &= ~0xFF) | 0X00000011; //clear PE0 and PE1 then set them as uart

}

// intia portE uart7 as gps



uint8_t UART7_AVAILABLE(void){
        return (((UART7_FR_R & UART_FR_RXFE)) == UART_FR_RXFE) ? 0:1 ;
}

uint8_t UART0_AVAILABLE(void){
        return (((UART0_FR_R & UART_FR_RXFE)) == UART_FR_RXFE) ? 0:1 ;
}

uint8_t UART7_read(void){
     while (UART7_AVAILABLE() != 1){};
    return (UART7_DR_R & 0xFF);
}

uint8_t UART0_read(void){
    while (UART0_AVAILABLE() != 1){};
    return (UART0_DR_R & 0xFF);
}

void UART7_write(char c){
    while ((UART7_FR_R & UART_FR_TXFF ) == UART_FR_TXFF){};
    UART7_DR_R = c;

}
void UART0_write(char c){
    while ((UART0_FR_R & UART_FR_TXFF ) == UART_FR_TXFF){};
    UART0_DR_R = c;

}



void UART7_readstr(char* str){
    int i=0;
    char c;

while(1){
    int cuntrighr=0;
        c=UART7_read();

        if(c == '$'){
            cuntrighr++;
                    c=UART7_read();

                    if(c== 'G'){
                        cuntrighr++;
                        c=UART7_read();

                        if(c == 'P'){
                            cuntrighr++;
                            c=UART7_read();

                            if(c == 'R'){
                                cuntrighr++;
                                c=UART7_read();

                                if(c == 'M'){
                                    cuntrighr++;
                                    c=UART7_read();

                                    if(c == 'C'){
                                        cuntrighr++;
                                        while(1){

                                              c=UART7_read();

                                              if(c == 'A'){
                                                  cuntrighr++;
                                              }



        str[i]=c;
        i++;
        if (c== '\n' || c == '\r'||c=='*')
                   {break;}
                                    }
                                }
                            }
                        }
                    }
        }
    }
        if(cuntrighr==8)break;
}

}
void UART0_printf(char* str){

    while(*str){
        UART0_write(*str);
        str++;
    }
}


uint32_t data_read = 0;

void EEPROMINIT(void){
    SYSCTL_RCGCEEPROM_R |= SYSCTL_RCGCEEPROM_R0;    // enable eprom clk
    while((SYSCTL_PREEPROM_R & SYSCTL_RCGCEEPROM_R0)==0); /// delay // stuck here using simulation
    while((EEPROM_EEDONE_R & EEPROM_EEDONE_WORKING) != 0 );   // wait untill    (EEDONE) be clear (ready)
    if(((EEPROM_EESUPP_R & EEPROM_EESUPP_PRETRY) | (EEPROM_EESUPP_R & EEPROM_EESUPP_PRETRY ) ) != 0){
       //error , need to reach error handler
    }
    SYSCTL_SREEPROM_R |=  SYSCTL_SREEPROM_R0; //Reset the EEPROM module
    SYSCTL_SREEPROM_R &= ~SYSCTL_SREEPROM_R0;
    while((SYSCTL_PREEPROM_R & SYSCTL_SREEPROM_R0)==0);  /// delay
    while((EEPROM_EEDONE_R & EEPROM_EEDONE_WORKING) != 0 ); //  wait till be ready
}


// start address 0x0 , end address 0x7FC
void EEPROM_Write(uint32_t address, uint32_t data) {
    while((EEPROM_EEDONE_R & EEPROM_EEDONE_WORKING)!=0);     // Wait for the EEPROM to be ready
    // Set the address to write to
    EEPROM_EEBLOCK_R = address / 16;         // 16 words per block
    EEPROM_EEOFFSET_R = (address % 16);  // 4 words per offset
    EEPROM_EERDWR_R = data;    // Write the data THIS IS NEW BOODY

//  Deleted probably will give error  *((volatile uint32_t*)(EEPROM_EESIZE_R + address)) = data ;    // check this line EEPROM_EESIZE_R should be the base address of eeprom which is 0x400AF000

    while((EEPROM_EEDONE_R & EEPROM_EEDONE_WORKING)!=0); // Wait for the write to complete
    // Check for any errors
    if(EEPROM_EESUPP_R & (EEPROM_EESUPP_PRETRY | EEPROM_EESUPP_ERETRY)) {
        // Handle error
    }
}


// start adress 0x0 , end address 0x7FC
uint32_t EEPROM_Read(uint32_t address) {
    while((EEPROM_EEDONE_R & EEPROM_EEDONE_WORKING)!=0);    // Wait for the EEPROM to be ready
    // Set the address to read from
    EEPROM_EEBLOCK_R = address / 16;        // 16 words per block
    EEPROM_EEOFFSET_R = (address % 16); // 4 words per offset REMOVE DIVIDE BY 4
    data_read = EEPROM_EERDWR_R;   // Read the data// check this line EEPROM_EESIZE_R should be the base address of eeprom which is 0x400AF000
    // Check for any errors
    if(EEPROM_EESUPP_R & (EEPROM_EESUPP_PRETRY | EEPROM_EESUPP_ERETRY)) {
        // Handle error
    }
    return data_read;
}



void splitString(char *inputString, char delimiter, char result[15][15]) {
        int i;
        int row = 0, col = 0;

        for (i = 0; inputString[i] != '\0'; i++) {
            if (inputString[i] != delimiter) {
                result[row][col++] = inputString[i];
            } else {
                result[row][col] = '\0'; // Null-terminate the string
                row++;
                col = 0;
            }
        }
        result[row][col] = '\0'; // Null-terminate the last string
    }


float todeg (float angle)
{
    float degree=(float)angle/100;
    float minutes =angle-(float)degree*100;
    return(degree+(minutes/60));
}


////////////////////////
////////////////////////
////////////////////////




float torad (float angle)
{
    return ((angle*3.14159265359)/180);
}


char lattt[15]={0};
char longgg[15]={0};
void get_deg (uint32_t latt ,uint32_t longg)
{

    float rad_lat=todeg(((float)(float)latt/100000))+0.0258888+0.000424-0.0012263;
    float rad_long=todeg((float)((float)longg/100000))+0.1109375+0.0002852+0.0010712;
    sprintf(lattt,"%.*f",7,rad_lat);
    sprintf(longgg,"%.*f",7,rad_long);
    UART0_printf(lattt);
    UART0_printf(",");
    UART0_printf(longgg);
    UART0_printf("\n");

}


float get_distance(float current_long,float current_lat,float next_long,float next_lat)
{

float deg_1 =todeg(current_long);
     float  current_long_rad =torad(deg_1);


    float deg_2=todeg(current_lat);
    float current_lat_rad=torad(deg_2);


    float deg_3=todeg(next_long);
    float next_long_rad=torad(deg_3);

    float deg_4=todeg(next_lat);
    float next_lat_rad=torad(deg_4);




    float longdiff=next_long_rad-current_long_rad;
    float latdiff=next_lat_rad-current_lat_rad;

    float a=pow(sin(latdiff/2),2)+cos(current_lat_rad)*cos(next_lat_rad)*pow(sin(longdiff/2),2);
    float  c=2*atan2(sqrt(a),sqrt(1-a));
    return 6371000*c;
}
void lat_1 ()
{
     if(strcmp(splited[4],"N")==0)
        {
             current_lat=atof(splited[3]);
        }
        else
        {
              current_lat=-1*(atof(splited[3]));
        }


}
void lat_2 ()
{
     if(strcmp(splited[4],"N")==0)
        {
             next_lat=atof(splited[3]);
        }
        else
        {
              next_lat=-1*(atof(splited[3]));
        }


}
void long_1()
{
      if(strcmp(splited[6],"E")==0)
            {
             current_long=(atof(splited[5]));
        }
        else
        {
             current_long=-1*(atof(splited[5]));
        }
}
void long_2()
{
      if(strcmp(splited[6],"E")==0)
            {
             next_long=(atof(splited[5]));
        }
        else
        {
             next_long=-1*(atof(splited[5]));
        }
}

int main(){
    portBInit();
    RGBInit ();
    systick_init();
    UART0Init();
    UART7Init();
    LCD_Init();
    EEPROMINIT();
    int counter_eeprom_write=0;
    int counter_eeprom_read=0;
    int lat=0;
    int loong=0;
    UART7_readstr(test);
    splitString(test,',',splited);
    lat =(float)atof(splited[3])*100000;
    EEPROM_Write(counter_eeprom_write,lat);
    counter_eeprom_write+=4;
    loong =(float)atof(splited[5])*100000;
    EEPROM_Write(counter_eeprom_write,loong);
    counter_eeprom_write+=4;
    LCD_CMD(0x80);
               LCD_SendString("DIS:",4);
               LCD_CMD(0xC0);
               LCD_SendString("0",1);
    lat_1();
      long_1();

    while(1){
    UART7_readstr(test);

    splitString(test,',',splited);

    lat_2();
        long_2();
        //sprintf(test2, "%.*f", 5, distance);
        //UART0_printf(test2);
        //UART0_printf("\n");
        if(get_distance(next_long,next_lat,current_long,current_lat)>3&&get_distance(next_long,next_lat,current_long,current_lat)<150){
            lat =(float)atof(splited[3])*100000;
                  EEPROM_Write(counter_eeprom_write,lat);
                  counter_eeprom_write+=4;
                  loong =(float)atof(splited[5])*100000;
                  EEPROM_Write(counter_eeprom_write,loong);
                  counter_eeprom_write+=4;
        distance=distance+get_distance(next_long,next_lat,current_long,current_lat);

            delay_IN_ms(500);
            sprintf(test2, "%.*f", 5, distance);
            LCD_CMD(0x80);
            LCD_SendString("DIS:",4);
            LCD_CMD(0xC0);
            LCD_SendString(test2,strlen(test2));
            lat_1();
            long_1();
            if(distance>100){
                LCD_CMD(0x80);
                           LCD_SendString("DIS:",4);
                           LCD_CMD(0xC0);
                           LCD_SendString("Arrived  ",9);
                GPIO_PORTF_DATA_R=0x04;
                       for( counter_eeprom_read=0;counter_eeprom_read <counter_eeprom_write ; counter_eeprom_read+=8){
                       get_deg(EEPROM_Read(counter_eeprom_read),EEPROM_Read(counter_eeprom_read+4));


                   }
                       GPIO_PORTF_DATA_R=0x08;
            while(1){

                UART0_printf(lattt);
                    UART0_printf(",");
                    UART0_printf(longgg);
                    UART0_printf("\n");

            }}
    }
    }}

